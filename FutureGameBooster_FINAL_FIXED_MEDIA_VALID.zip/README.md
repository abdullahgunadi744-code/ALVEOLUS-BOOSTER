# Future Game Booster — Booster AI 1.2 FINAL MEDIA

Android project for the Future Game Booster / Booster AI app.

## Included
- Modern dark gaming UI.
- 8-second H.264 intro/hero video bundled in the APK.
- 17-second MP3 music bundled in the APK, looped on the home screen.
- Music mute/unmute control.
- Video loops on the home screen.
- Video Overlay button in the floating Booster/Crosshair panel.
- Crosshair overlay service.
- Booster + Crosshair floating panel.
- Installed app/game selector.
- Display refresh-rate information.
- Safe-mode booster controls (UI/system-safe actions only).

## Build
- JDK 17
- Gradle 8.11.1
- Android Gradle Plugin 8.9.1
- compileSdk 35
- minSdk 26

The workflow can generate the Gradle wrapper with Gradle 8.11.1 and then run `./gradlew clean assembleDebug`.
