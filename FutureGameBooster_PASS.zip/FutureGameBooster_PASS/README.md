Future Game Booster / Booster AI
Build target: Android, JDK 17, Gradle 8.11.1, AGP 8.9.1.
This project intentionally uses only Android framework APIs for the app code to reduce dependency-related build failures.
