package com.futuregamebooster.boosterai;

import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root; VideoView video; MediaPlayer music; TextView musicBtn; boolean musicOn=true; Handler handler=new Handler(Looper.getMainLooper());
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);} 
    TextView text(String s,float size,boolean bold){ TextView v=new TextView(this); v.setText(s); v.setTextColor(Color.WHITE); v.setTextSize(size); if(bold)v.setTypeface(null,1); v.setGravity(Gravity.CENTER_VERTICAL); return v; }
    GradientDrawable bg(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    @Override public void onCreate(Bundle b){super.onCreate(b);build();startMusic();}
    void build(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(10),dp(16),dp(24)); root.setBackgroundColor(Color.rgb(5,0,15)); scroll.addView(root); setContentView(scroll);
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL); ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.booster_logo); head.addView(logo,new LinearLayout.LayoutParams(dp(58),dp(58))); TextView title=text("BOOSTER AI\nFUTURE GAME CONTROL",20,true); head.addView(title,new LinearLayout.LayoutParams(0,dp(58),1)); TextView clock=text("--:--:--",16,true); clock.setGravity(Gravity.CENTER); head.addView(clock,new LinearLayout.LayoutParams(dp(88),dp(58))); root.addView(head);
        Runnable tick=new Runnable(){public void run(){clock.setText(new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date())); handler.postDelayed(this,1000);}}; handler.post(tick);
        TextView status=text("● SYSTEM READY  •  BOOSTER ONLINE",11,true); root.addView(status,new LinearLayout.LayoutParams(-1,dp(34))); addHero();
        TextView mt=text("LAUNCH MODES",15,true); mt.setPadding(dp(2),dp(14),0,dp(8)); root.addView(mt);
        LinearLayout modes=new LinearLayout(this); modes.setGravity(Gravity.CENTER); Button booster=button("🚀 BOOSTER\nGame Booster panel"); booster.setOnClickListener(v->launch(OverlayService.MODE_BOOSTER,null)); Button cross=button("🎯 CROSSHAIR\nAim overlay panel"); cross.setOnClickListener(v->launch(OverlayService.MODE_CROSSHAIR,null)); modes.addView(booster,new LinearLayout.LayoutParams(0,dp(90),1)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(90),1);cp.leftMargin=dp(8);modes.addView(cross,cp);root.addView(modes);
        TextView gt=text("GAME / APP SELECTOR",15,true);gt.setPadding(dp(2),dp(16),0,dp(8));root.addView(gt); addApps();
        TextView dt=text("DISPLAY",15,true);dt.setPadding(dp(2),dp(16),0,dp(8));root.addView(dt); TextView di=text(refreshInfo(),13,false);di.setPadding(dp(14),dp(12),dp(14),dp(12));di.setTextColor(Color.WHITE);di.setBackground(bg(Color.rgb(18,3,29),18));root.addView(di);
    }
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackground(bg(Color.rgb(28,5,45),20));return b;}
    void addHero(){FrameLayout f=new FrameLayout(this);f.setBackground(bg(Color.rgb(10,2,18),24));video=new VideoView(this);video.setVideoURI(Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.booster_intro));video.setOnPreparedListener(mp->{mp.setLooping(true);mp.setVolume(0,0);video.start();});f.addView(video,new FrameLayout.LayoutParams(-1,dp(205))); TextView t=text("BOOST YOUR GAME\nPERFORMANCE • AIM • CONTROL",20,true);t.setPadding(dp(16),dp(12),dp(16),dp(12));FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,dp(205),Gravity.BOTTOM);f.addView(t,tp);musicBtn=text("♫ MUSIC ON",11,true);musicBtn.setGravity(Gravity.CENTER);musicBtn.setBackground(bg(Color.rgb(25,5,35),16));musicBtn.setOnClickListener(v->toggleMusic());FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(112),dp(40),Gravity.TOP|Gravity.RIGHT);mp.setMargins(0,dp(12),dp(12),0);f.addView(musicBtn,mp);root.addView(f,new LinearLayout.LayoutParams(-1,dp(205)));}
    void startMusic(){music=MediaPlayer.create(this,R.raw.booster_music);if(music!=null){music.setLooping(true);music.setVolume(.55f,.55f);music.start();}}
    void toggleMusic(){if(music==null)return;musicOn=!musicOn;if(musicOn){music.setVolume(.55f,.55f);music.start();musicBtn.setText("♫ MUSIC ON");}else{music.pause();musicBtn.setText("♫ MUSIC OFF");}}
    String refreshInfo(){android.view.Display d=((android.view.WindowManager)getSystemService(WINDOW_SERVICE)).getDefaultDisplay();StringBuilder s=new StringBuilder("CURRENT  ").append((int)d.getRefreshRate()).append(" Hz\nSUPPORTED  ");android.view.Display.Mode[] ms=d.getSupportedModes();for(int i=0;i<ms.length;i++){if(i>0)s.append(" / ");s.append((int)ms[i].getRefreshRate());}return s.append(" Hz").toString();}
    void addApps(){Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> list=getPackageManager().queryIntentActivities(i,0);Collections.sort(list,(a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));int n=Math.min(40,list.size());for(int x=0;x<n;x++){ResolveInfo r=list.get(x);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(4),dp(8),dp(4));row.setBackground(bg(Color.rgb(14,4,24),16));ImageView ic=new ImageView(this);ic.setImageDrawable(r.loadIcon(getPackageManager()));row.addView(ic,new LinearLayout.LayoutParams(dp(42),dp(42)));row.addView(text(r.loadLabel(getPackageManager()).toString(),14,true),new LinearLayout.LayoutParams(0,dp(52),1));Button go=button("BOOST");String pkg=r.activityInfo.packageName;go.setOnClickListener(v->launch(OverlayService.MODE_BOOSTER,pkg));row.addView(go,new LinearLayout.LayoutParams(dp(90),dp(48)));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(60));rp.bottomMargin=dp(6);root.addView(row,rp);}}
    void launch(String mode,String pkg){if(!Settings.canDrawOverlays(this)){try{startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));}catch(Exception e){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));}Toast.makeText(this,"Aktifkan izin overlay lalu tekan lagi.",Toast.LENGTH_LONG).show();return;}Intent i=new Intent(this,OverlayService.class);i.setAction(OverlayService.ACTION_SHOW);i.putExtra(OverlayService.EXTRA_MODE,mode);if(pkg!=null)i.putExtra(OverlayService.EXTRA_PACKAGE,pkg);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}
    @Override protected void onPause(){super.onPause();if(musicOn&&music!=null&&music.isPlaying())music.pause();}
    @Override protected void onResume(){super.onResume();if(musicOn&&music!=null&&!music.isPlaying())music.start();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);if(video!=null)video.stopPlayback();if(music!=null){try{music.stop();}catch(Exception ignored){}music.release();}super.onDestroy();}
}
