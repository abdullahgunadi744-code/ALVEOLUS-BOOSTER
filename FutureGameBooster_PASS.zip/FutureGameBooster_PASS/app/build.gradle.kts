plugins { id("com.android.application") }

android {
    namespace = "com.futuregamebooster.boosterai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.futuregamebooster.boosterai"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "1.3"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
