package com.future.gamebooster

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF05070D)
private val Panel = Color(0xFF0B101B)
private val Cyan = Color(0xFF00E5FF)
private val Purple = Color(0xFF9C5CFF)
private val Green = Color(0xFF35FF9A)
private val TextPrimary = Color(0xFFEAF7FF)
private val Muted = Color(0xFF7D91A5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FutureBoosterApp() }
    }
}

@Composable
private fun FutureBoosterApp() {
    var boosted by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf("Cyber Arena") }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Bg)
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("FUTURE", color = Cyan, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            Text("GAME BOOSTER", color = TextPrimary, fontSize = 25.sp, fontWeight = FontWeight.Black)

            HudCard {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        if (boosted) "BOOST ACTIVE" else "SYSTEM READY",
                        color = if (boosted) Green else Cyan,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        if (boosted) "MAX" else "98",
                        color = TextPrimary,
                        fontSize = 52.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text("PERFORMANCE %", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("FPS", if (boosted) "60+" else "59", Cyan, Modifier.weight(1f))
                StatCard("RAM", "2.8 GB", Purple, Modifier.weight(1f))
                StatCard("TEMP", if (boosted) "42°C" else "39°C", Green, Modifier.weight(1f))
            }

            Button(
                onClick = { boosted = !boosted },
                modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (boosted) Color(0xFF123D2A) else Color(0xFF102A35)
                )
            ) {
                Text(
                    if (boosted) "⚡ BOOST ACTIVE — TAP TO STOP" else "⚡ ACTIVATE TURBO BOOST",
                    color = if (boosted) Green else Cyan,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Text("MODULES", color = Muted, fontSize = 11.sp, letterSpacing = 3.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModuleCard("RAM\nOPTIMIZER", "READY", Cyan, Modifier.weight(1f))
                ModuleCard("GPU\nMODE", "AUTO", Purple, Modifier.weight(1f))
                ModuleCard("NETWORK\nTUNER", "READY", Green, Modifier.weight(1f))
            }

            HudCard {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("GAME LAUNCHER", color = TextPrimary, fontWeight = FontWeight.Bold)
                    listOf("Cyber Arena", "Neon Racer", "Battle Zone").forEach { name ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF101827), RoundedCornerShape(12.dp))
                                .clickable { selected = name }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("◈", color = Cyan, fontSize = 18.sp)
                            Spacer(Modifier.width(12.dp))
                            Text(name, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.weight(1f))
                            Text(
                                if (selected == name) "SELECTED" else "PLAY",
                                color = if (selected == name) Green else Muted,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.weight(1f))
            Text(
                "v1.0 • FUTURE PERFORMANCE ENGINE",
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF405064),
                fontSize = 9.sp,
                letterSpacing = 2.sp
            )
        }
    }
}

@Composable
private fun HudCard(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(22.dp))
            .border(1.dp, Color(0xFF17283B), RoundedCornerShape(22.dp))
    ) { content() }
}

@Composable
private fun StatCard(title: String, value: String, accent: Color, modifier: Modifier) {
    Box(
        modifier
            .height(80.dp)
            .background(Panel, RoundedCornerShape(16.dp))
            .border(1.dp, accent.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(value, color = accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun ModuleCard(title: String, status: String, accent: Color, modifier: Modifier) {
    Box(
        modifier
            .height(92.dp)
            .background(Panel, RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF17283B), RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(title, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("● $status", color = accent, fontSize = 9.sp)
        }
    }
}
