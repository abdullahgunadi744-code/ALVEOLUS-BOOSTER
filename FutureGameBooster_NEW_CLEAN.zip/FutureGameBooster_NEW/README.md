# Future Game Booster — Booster AI (Clean Build)

Clean Android project for GitHub Actions.

- Namespace: `com.futuregamebooster.boosterai`
- Gradle: 8.11.1
- Android Gradle Plugin: 8.9.1
- Kotlin: 2.1.20
- JDK: 17
- Target SDK: 35
- Includes the supplied intro video and looping music.
- Includes Booster/Crosshair overlay service.

The workflow builds the project directly. It does not extract another ZIP, so there is no nested-project ambiguity.
