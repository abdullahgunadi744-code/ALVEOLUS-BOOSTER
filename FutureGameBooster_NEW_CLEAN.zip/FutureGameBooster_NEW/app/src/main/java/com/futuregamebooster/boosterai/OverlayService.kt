package com.futuregamebooster.boosterai

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import android.net.Uri

class OverlayService : Service() {
    companion object {
        const val ACTION_SHOW = "com.futuregamebooster.boosterai.SHOW"
        const val ACTION_STOP = "com.futuregamebooster.boosterai.STOP"
        const val EXTRA_MODE = "mode"
        const val EXTRA_PACKAGE = "game_package"
        const val MODE_BOOSTER = "booster"
        const val MODE_CROSSHAIR = "crosshair"
        private const val CHANNEL = "booster_overlay"
        private const val NOTIFICATION_ID = 7001
    }

    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var crosshair: CrosshairView? = null
    private var videoOverlay: VideoView? = null
    private var selectedPackage: String? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, notification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        selectedPackage = intent?.getStringExtra(EXTRA_PACKAGE) ?: selectedPackage
        showPanel(intent?.getStringExtra(EXTRA_MODE) ?: MODE_BOOSTER)
        return START_STICKY
    }

    private fun layoutParams(width: Int, height: Int, gravity: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            format = PixelFormat.TRANSLUCENT
        }

    private fun showPanel(mode: String) {
        removePanel()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            background = rounded(Color.argb(235, 14, 2, 28), 28)
        }
        val title = TextView(this).apply {
            text = if (mode == MODE_CROSSHAIR) "🎯  CROSSHAIR + BOOSTER" else "⚡  BOOSTER + CROSSHAIR"
            textSize = 18f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 8)
        }
        root.addView(title)

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(button("BOOSTER") { showBoosterControls(root) }, LinearLayout.LayoutParams(0, 48, 1f).apply { rightMargin = 5 })
        row.addView(button("CROSSHAIR") { toggleCrosshair() }, LinearLayout.LayoutParams(0, 48, 1f).apply { leftMargin = 5 })
        root.addView(row)
        root.addView(button("🎬 VIDEO OVERLAY") { toggleVideoOverlay() }, LinearLayout.LayoutParams(-1, 46).apply { topMargin = 8 })
        root.addView(button("✕ CLOSE PANEL") { stopSelf() }, LinearLayout.LayoutParams(-1, 46).apply { topMargin = 8 })

        panel = root
        wm.addView(root, layoutParams(360, WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { y = 42 })
        if (mode == MODE_CROSSHAIR) toggleCrosshair()
        if (selectedPackage != null) launchSelectedGame()
    }

    private fun showBoosterControls(parent: LinearLayout) {
        val dialog = Dialog(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            background = rounded(Color.rgb(14, 2, 28), 24)
        }
        val title = TextView(this).apply { text = "⚡ BOOSTER CONTROLS"; textSize = 20f; setTextColor(Color.WHITE) }
        box.addView(title)
        listOf("Turbo Mode", "Performance HUD", "Touch Response", "Do Not Disturb").forEach { name ->
            box.addView(Switch(this).apply { text = name; isChecked = false; setTextColor(Color.WHITE) })
        }
        box.addView(button("APPLY") { dialog.dismiss(); Toast.makeText(this, "Booster profile aktif (safe mode)", Toast.LENGTH_SHORT).show() })
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
    }

    private fun toggleCrosshair() {
        if (crosshair == null) {
            crosshair = CrosshairView(this)
            wm.addView(crosshair, layoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, Gravity.TOP or Gravity.START).apply {
                flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            })
            Toast.makeText(this, "Crosshair ON", Toast.LENGTH_SHORT).show()
        } else {
            removeCrosshair()
            Toast.makeText(this, "Crosshair OFF", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleVideoOverlay() {
        if (videoOverlay != null) {
            removeVideoOverlay()
            Toast.makeText(this, "Video overlay OFF", Toast.LENGTH_SHORT).show()
            return
        }
        val view = VideoView(this).apply {
            setBackgroundColor(Color.BLACK)
            setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.booster_intro}"))
            setOnPreparedListener { mp ->
                mp.isLooping = true
                mp.setVolume(0f, 0f)
                start()
            }
            setOnErrorListener { _, _, _ ->
                Toast.makeText(this@OverlayService, "Video overlay gagal diputar di perangkat ini", Toast.LENGTH_SHORT).show()
                removeVideoOverlay()
                true
            }
        }
        videoOverlay = view
        val close = Button(this).apply {
            text = "✕"
            textSize = 14f
            setOnClickListener { removeVideoOverlay() }
        }
        val container = FrameLayout(this).apply {
            background = rounded(Color.BLACK, 20)
            addView(view, FrameLayout.LayoutParams(320, 180))
            addView(close, FrameLayout.LayoutParams(52, 48, Gravity.TOP or Gravity.END))
        }
        view.tag = container
        wm.addView(container, layoutParams(320, 180, Gravity.BOTTOM or Gravity.END).apply {
            x = 16
            y = 120
        })
        Toast.makeText(this, "Video overlay ON", Toast.LENGTH_SHORT).show()
    }

    private fun removeVideoOverlay() {
        val view = videoOverlay ?: return
        val container = view.tag as? View
        runCatching { view.stopPlayback() }
        if (container != null) runCatching { wm.removeView(container) }
        videoOverlay = null
    }

    private fun launchSelectedGame() {
        val pkg = selectedPackage ?: return
        selectedPackage = null
        Handler(Looper.getMainLooper()).postDelayed({
            packageManager.getLaunchIntentForPackage(pkg)?.let { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(it) }
        }, 250)
    }

    private fun button(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { click() }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }

    private fun removePanel() { panel?.let { runCatching { wm.removeView(it) }; panel = null } }
    private fun removeCrosshair() { crosshair?.let { runCatching { wm.removeView(it) }; crosshair = null } }

    override fun onDestroy() {
        removePanel()
        removeCrosshair()
        removeVideoOverlay()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Booster AI Overlay", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(): Notification {
        val stop = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.booster_logo)
            .setContentTitle("Booster AI aktif")
            .setContentText("Overlay Booster / Crosshair sedang berjalan")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "STOP", stop).build())
            .build()
    }

    private class CrosshairView(context: Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = Color.WHITE
            canvas.drawCircle(cx, cy, 18f, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(190, 50, 255)
            canvas.drawCircle(cx, cy, 3.5f, paint)
            paint.strokeWidth = 2f
            paint.style = Paint.Style.STROKE
            canvas.drawLine(cx - 34, cy, cx - 10, cy, paint)
            canvas.drawLine(cx + 10, cy, cx + 34, cy, paint)
            canvas.drawLine(cx, cy - 34, cx, cy - 10, paint)
            canvas.drawLine(cx, cy + 10, cx, cy + 34, paint)
        }
    }
}
