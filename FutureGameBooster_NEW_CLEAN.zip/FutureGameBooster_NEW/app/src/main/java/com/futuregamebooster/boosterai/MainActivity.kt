package com.futuregamebooster.boosterai

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var box: LinearLayout
    private lateinit var video: VideoView
    private lateinit var musicButton: TextView
    private var music: MediaPlayer? = null
    private var musicOn = true
    private val handler = Handler(Looper.getMainLooper())

    private fun d(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun bg(color: Int, radius: Int = 22, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = d(radius).toFloat()
        stroke?.let { setStroke(d(1), it) }
    }

    private fun card(title: String, sub: String, go: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(d(12), d(10), d(12), d(10))
        background = bg(Color.rgb(28, 5, 45), 20, Color.rgb(100, 35, 145))
        setOnClickListener { go() }
        addView(tv(title, 19f, true))
        addView(tv(sub, 11f))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        startMusic()
    }

    private fun buildUi() {
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(16), d(10), d(16), d(24))
            setBackgroundColor(Color.rgb(5, 0, 15))
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(5, 0, 15)) }
        scroll.addView(box)
        setContentView(scroll)

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val image = ImageView(this).apply { setImageResource(R.drawable.booster_ai_logo) }
        header.addView(image, LinearLayout.LayoutParams(d(58), d(58)))
        val title = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        title.addView(tv("BOOSTER AI", 22f, true))
        title.addView(tv("FUTURE GAME CONTROL", 10f))
        header.addView(title, LinearLayout.LayoutParams(0, d(58), 1f))
        val clock = tv("--:--:--", 16f, true).apply { gravity = Gravity.CENTER }
        header.addView(clock, LinearLayout.LayoutParams(d(88), d(58)))
        box.addView(header)

        val tick = object : Runnable {
            override fun run() {
                clock.text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                image.rotation = (image.rotation + 8f) % 360f
                handler.postDelayed(this, 1000L)
            }
        }
        handler.post(tick)

        box.addView(tv("● SYSTEM READY  •  BOOSTER ONLINE", 11f, true), LinearLayout.LayoutParams(-1, d(34)))
        addHeroVideo()

        val modeTitle = tv("LAUNCH MODES", 15f, true)
        modeTitle.setPadding(d(2), d(14), 0, d(8))
        box.addView(modeTitle)
        val modes = LinearLayout(this).apply { gravity = Gravity.CENTER }
        modes.addView(card("🚀 BOOSTER", "Game Booster panel") { launchOverlay(OverlayService.MODE_BOOSTER) }, LinearLayout.LayoutParams(0, d(108), 1f).apply { rightMargin = d(5) })
        modes.addView(card("🎯 CROSSHAIR", "Aim overlay panel") { launchOverlay(OverlayService.MODE_CROSSHAIR) }, LinearLayout.LayoutParams(0, d(108), 1f).apply { leftMargin = d(5) })
        box.addView(modes)

        val selectorTitle = tv("GAME / APP SELECTOR", 15f, true)
        selectorTitle.setPadding(d(2), d(16), 0, d(8))
        box.addView(selectorTitle)
        addApps()

        val displayTitle = tv("DISPLAY", 15f, true)
        displayTitle.setPadding(d(2), d(16), 0, d(8))
        box.addView(displayTitle)
        box.addView(tv(refreshInfo(), 13f).apply {
            setPadding(d(14), d(12), d(14), d(12))
            background = bg(Color.rgb(18, 3, 29), 18, Color.rgb(75, 25, 105))
        })
    }

    private fun addHeroVideo() {
        val frame = FrameLayout(this).apply {
            background = bg(Color.rgb(10, 2, 18), 24, Color.rgb(105, 40, 150))
            clipToOutline = true
        }
        video = VideoView(this)
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.booster_intro}"))
        video.setOnPreparedListener { mp ->
            mp.isLooping = true
            mp.setVolume(0f, 0f)
            video.start()
        }
        frame.addView(video, FrameLayout.LayoutParams(-1, d(205)))

        val shade = View(this).apply { setBackgroundColor(Color.argb(70, 0, 0, 0)) }
        frame.addView(shade, FrameLayout.LayoutParams(-1, d(205)))

        val text = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(16), d(12), d(16), d(12))
            gravity = Gravity.BOTTOM
        }
        text.addView(tv("BOOST YOUR GAME", 21f, true))
        text.addView(tv("PERFORMANCE • AIM • CONTROL", 10f, true))
        frame.addView(text, FrameLayout.LayoutParams(-1, d(205)))

        musicButton = TextView(this).apply {
            text = "♫ MUSIC ON"
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = bg(Color.argb(190, 20, 5, 32), 16, Color.rgb(150, 60, 210))
            setOnClickListener { toggleMusic() }
        }
        frame.addView(musicButton, FrameLayout.LayoutParams(d(112), d(40), Gravity.TOP or Gravity.END).apply {
            topMargin = d(12)
            rightMargin = d(12)
        })
        box.addView(frame, LinearLayout.LayoutParams(-1, d(205)).apply { bottomMargin = d(4) })
    }

    private fun startMusic() {
        music = MediaPlayer.create(this, R.raw.booster_music)?.apply {
            isLooping = true
            setVolume(0.55f, 0.55f)
            start()
        }
    }

    private fun toggleMusic() {
        val player = music ?: return
        musicOn = !musicOn
        if (musicOn) {
            player.setVolume(0.55f, 0.55f)
            if (!player.isPlaying) player.start()
            musicButton.text = "♫ MUSIC ON"
        } else {
            player.pause()
            musicButton.text = "♫ MUSIC OFF"
        }
    }

    private fun refreshInfo(): String {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val modes = wm.defaultDisplay.supportedModes
            .map { it.refreshRate.toInt() }
            .distinct()
            .sorted()
        return "CURRENT  ${wm.defaultDisplay.refreshRate.toInt()} Hz\nSUPPORTED  ${modes.joinToString(" / ")} Hz"
    }

    private fun addApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(intent, 0)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase(Locale.getDefault()) }
            .take(40)

        list.forEach { info ->
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(d(8), d(4), d(8), d(4))
                background = bg(Color.rgb(14, 4, 24), 16, Color.rgb(50, 18, 70))
            }
            val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(pm)) }
            row.addView(icon, LinearLayout.LayoutParams(d(42), d(42)))
            row.addView(tv(info.loadLabel(pm).toString(), 14f, true), LinearLayout.LayoutParams(0, d(52), 1f))
            val launch = Button(this).apply {
                text = "BOOST"
                setOnClickListener { launchOverlay(OverlayService.MODE_BOOSTER, info.activityInfo.packageName) }
            }
            row.addView(launch, LinearLayout.LayoutParams(d(90), d(48)))
            box.addView(row, LinearLayout.LayoutParams(-1, d(60)).apply { bottomMargin = d(6) })
        }
    }

    private fun launchOverlay(mode: String, packageName: String? = null) {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${this.packageName}")))
            Toast.makeText(this, "Aktifkan izin tampil di atas aplikasi, lalu tekan tombol lagi.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_SHOW
            putExtra(OverlayService.EXTRA_MODE, mode)
            putExtra(OverlayService.EXTRA_PACKAGE, packageName)
        }
        startService(intent)
    }

    override fun onPause() {
        super.onPause()
        if (musicOn) music?.pause()
    }

    override fun onResume() {
        super.onResume()
        if (musicOn) music?.let { if (!it.isPlaying) it.start() }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        video.stopPlayback()
        music?.let { runCatching { it.stop() }; it.release() }
        music = null
        super.onDestroy()
    }
}
