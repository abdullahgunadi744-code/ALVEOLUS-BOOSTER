package com.futuregamebooster.boosterai
import android.app.*; import android.content.*; import android.graphics.*; import android.net.Uri; import android.os.*; import android.provider.Settings; import android.view.*; import android.widget.*; import androidx.appcompat.app.AppCompatActivity; import java.text.SimpleDateFormat; import java.util.*
class MainActivity: AppCompatActivity(){
 private lateinit var box:LinearLayout
 fun d(n:Int)= (n*resources.displayMetrics.density).toInt()
 fun card(t:String,s:String,go:()->Unit)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;padding(d(10));setBackgroundColor(Color.rgb(28,5,45));setOnClickListener{go()};addView(tv(t,22));addView(tv(s,11))}
 fun tv(s:String,z:Float)=TextView(this).apply{text=s;textSize=z;setTextColor(Color.WHITE);gravity=Gravity.CENTER}
 override fun onCreate(b:Bundle?){super.onCreate(b); ui()}
 fun ui(){box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(d(18),d(12),d(18),d(24));setBackgroundColor(Color.rgb(5,0,15))}
  val sc=ScrollView(this);sc.addView(box);setContentView(sc)
  val head=LinearLayout(this); val im=ImageView(this);im.setImageResource(R.drawable.booster_logo);head.addView(im,LinearLayout.LayoutParams(d(62),d(62)))
  val title=LinearLayout(this);title.orientation=LinearLayout.VERTICAL;title.addView(tv("BOOSTER AI",23f));title.addView(tv("FUTURE GAME PANEL",11f));head.addView(title,LinearLayout.LayoutParams(0,d(62),1f))
  val clock=tv("--:--:--",18f);head.addView(clock);box.addView(head)
  Handler(Looper.getMainLooper()).post(object:Runnable{override fun run(){clock.text=SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(Date());im.rotation=im.rotation+20;Handler(Looper.getMainLooper()).postDelayed(this,1000)}})
  box.addView(tv("● SYSTEM READY  •  PANEL ONLINE",12f))
  box.addView(tv("LAUNCH MODES",15f))
  val modes=LinearLayout(this);modes.addView(card("🚀 BOOSTER","Game Booster panel"){panel(false)},LinearLayout.LayoutParams(0,d(120),1f));modes.addView(card("🎯 CROSSHAIR","Aim overlay panel"){panel(true)},LinearLayout.LayoutParams(0,d(120),1f));box.addView(modes)
  box.addView(tv("GAME / APP SELECTOR",15f));apps()
  box.addView(tv("DISPLAY",15f));box.addView(tv(refresh(),14f))
 }
 fun refresh():String{val w=getSystemService(WINDOW_SERVICE) as WindowManager;val a=w.defaultDisplay.supportedModes.map{it.refreshRate.toInt()}.distinct().sorted();return "CURRENT ${w.defaultDisplay.refreshRate.toInt()} Hz\nSUPPORTED ${a.joinToString(" / ")} Hz"}
 fun apps(){val p=packageManager;val i=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);p.queryIntentActivities(i,0).distinctBy{it.activityInfo.packageName}.take(25).forEach{r->val row=LinearLayout(this);row.gravity=Gravity.CENTER_VERTICAL;val n=tv(it.loadLabel(p).toString(),14f);row.addView(n,LinearLayout.LayoutParams(0,d(52),1f));val b=Button(this);b.text="BOOST";b.setOnClickListener{startActivity(p.getLaunchIntentForPackage(it.activityInfo.packageName));panel(false)};row.addView(b,LinearLayout.LayoutParams(d(85),d(48)));box.addView(row)}}
 fun panel(cross:Boolean){val q=Dialog(this);val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(d(20),d(20),d(20),d(20));l.setBackgroundColor(Color.rgb(12,2,22));l.addView(tv(if(cross)"🎯 CROSSHAIR PANEL" else "⚡ BOOSTER PANEL",20f));listOf(if(cross)"Crosshair Overlay" else "Turbo Mode",if(cross)"Center Dot" else "Performance HUD",if(cross)"Dynamic Glow" else "Touch Response").forEach{x->l.addView(Switch(this).apply{text=x;isChecked=true;setTextColor(Color.WHITE)})};val b=Button(this);b.text=if(cross)"LAUNCH CROSSHAIR" else "LAUNCH BOOSTER";b.setOnClickListener{if(cross)overlay();q.dismiss()};l.addView(b);q.setContentView(l);q.window?.setBackgroundDrawableResource(android.R.color.transparent);q.show()}
 fun overlay(){if(!Settings.canDrawOverlays(this)){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")));return};Toast.makeText(this,"Crosshair overlay siap",Toast.LENGTH_SHORT).show()}
}